(function($) {
    $(function() {

        $('.button-collapse').sideNav();
        $('.parallax').parallax();
        $('.scrollspy').scrollSpy();
        $('.modal-trigger').leanModal();
    }); // end of document ready
})(jQuery); // end of jQuery name space
